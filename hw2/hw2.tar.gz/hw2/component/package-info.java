/** <font color=red><b>[CSE461]</b></font> Implements the main components of  the RFID system: the reader, the tags, and the communication medium (as well as a BitMemory).
 */
package component;
